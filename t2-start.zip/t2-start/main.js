const app = Vue.createApp({
    data() {
        return {
            product: 'Socks',
            description: 'A sock is a piece of clothing that shoes or dresses the foot in order to warm it up or protect it from direct contact with the shoe.'
        }
    }
})  